package com.SpringData.SpringDataJPA2_Assignment2.Question1to5.controller;

import com.SpringData.SpringDataJPA2_Assignment2.Question1to5.entity.Employee;
import com.SpringData.SpringDataJPA2_Assignment2.Question1to5.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping("/create")
    public String studentCreate(@RequestBody Employee employee)
    {
        employeeService.studentCreate(employee);
        return "User Added";
    }

    @GetMapping("/find-all")
    public List<Employee> findAllEmployee()
    {
        List<Employee> employees = employeeService.findAllEmployee();
        return employees;
    }


    @GetMapping("/find-all-partial")
    public List<Object[]> findEmployeesPartialData()
    {
        List<Object[]> employees = employeeService.findAllEmployeePartial();
        return employees;
    }

    @GetMapping("/find-min-avg-salary")
    public List<Employee> findEmployeeMinSalary()
    {
        List<Employee> employeeMinSalary = employeeService.findEmployeeMinSalary();
        return employeeMinSalary;
    }


    @GetMapping("/update/{increment}")
    public String updateEmployeeSalary(@PathVariable Double increment)
    {
        employeeService.updateEmployee(increment);
        return "Result Updated";
    }

    @GetMapping("/delete/{salary}")
    public String deleteEmployee(@PathVariable Double salary){
        employeeService.deleteEmployee(salary);
        return "Employee With Minimum Salary Deleted";
    }


    @GetMapping("/last-name")
    public List<Employee> findEmployeeLastNameNQ()
    {
        List<Employee> employee = employeeService.findEmployeeLastName();
        return employee;
    }

    @GetMapping("/delete-greater-than-45")
    public String deleteEmployeeGreaterThan45()
    {
        employeeService.deleteEmployeeGreaterThan45();
        return "Deleted Employee Records Greater Than 45";
    }

}
