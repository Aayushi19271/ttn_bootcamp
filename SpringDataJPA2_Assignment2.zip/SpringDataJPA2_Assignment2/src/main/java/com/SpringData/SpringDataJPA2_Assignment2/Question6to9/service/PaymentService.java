package com.SpringData.SpringDataJPA2_Assignment2.Question6to9.service;

import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.entity.Check;
import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.entity.CreditCard;
import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.entity.Payment;
import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class PaymentService {

    @Autowired
    PaymentRepository paymentRepository;

    public Payment createPayment(CreditCard creditCard)
    {
        return paymentRepository.save(creditCard);
    }

    public Payment createCheckPayment(Check check)
    {
        return paymentRepository.save(check);
    }

}
