package com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.controller;

import com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.service.EmployeeServiceMapping;
import com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.entity.EmployeeMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employeesmapping")
public class EmployeeControllerMapping {

    @Autowired
    EmployeeServiceMapping employeeService;


    @PostMapping("/create")
    public String employeeCreate()
    {
        employeeService.employeeCreate();
        return "User Added";
    }

    @GetMapping("/find-all")
    public List<EmployeeMapping> findAllEmployee()
    {
        List<EmployeeMapping> employees = employeeService.findAllEmployee();
        return employees;
    }

}


