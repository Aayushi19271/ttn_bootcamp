package com.SpringData.SpringDataJPA2_Assignment2.Question6to9.repository;

import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.entity.Payment;
import org.springframework.data.repository.CrudRepository;

public interface PaymentRepository extends CrudRepository<Payment,Integer> {

}
