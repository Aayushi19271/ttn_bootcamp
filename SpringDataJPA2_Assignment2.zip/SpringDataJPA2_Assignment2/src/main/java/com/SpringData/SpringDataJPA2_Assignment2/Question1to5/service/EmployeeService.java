package com.SpringData.SpringDataJPA2_Assignment2.Question1to5.service;

import com.SpringData.SpringDataJPA2_Assignment2.Question1to5.entity.Employee;
import com.SpringData.SpringDataJPA2_Assignment2.Question1to5.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    //CREATE A EMPLOYEE
    public void studentCreate(Employee employee)
    {
        employeeRepository.save(employee);
    }

    //FETCH THE LIST OF ALL EMPLOYEES
    public List<Employee> findAllEmployee()
    {
        List<Employee> employees = (List<Employee>) employeeRepository.findAll();
        return employees;
    }

    //PARTIAL DATA
    public List<Object[]> findAllEmployeePartial() {
        List<Object[]> employeeList = employeeRepository.findAllEmployeePartialData();
        return employeeList;
    }

    public List<Employee> findEmployeeMinSalary()
    {
        List<Employee> employees = employeeRepository.selectAllEmployeeSalary();
        return employees;
    }

    //UPDATE THE EMPLOYEE SALARY
    public void updateEmployee(Double increment){
            Iterable<Employee> list = employeeRepository.findAll();
            Iterator<Employee> iterator = list.iterator();
            Double sum =0d;
            int count =0;
            while (iterator.hasNext())
            {
                Employee e = iterator.next();
                sum = sum + e.getSalary();
                count++;
            }
            Double average = sum/count;
            employeeRepository.updateAllEmployeeSalary(increment,average);
    }

    //DELETE THE EMPLOYEE WITH MINIMUM SALARY
    public void deleteEmployee(Double salary){
        employeeRepository.deleteAllEmployeesMinSalary(salary);
    }


    //Native SQL Query - Display the id, first name, age of all employees where last name ends with "singh"
    public List<Employee> findEmployeeLastName()
    {
        List<Employee> lastNameNQ= employeeRepository.findEmployeeLastNameNQ("singh");
        return lastNameNQ;
    }

    //Native SQL Query - Delete all employees with age greater than 45(Should be passed as a parameter)
    public void deleteEmployeeGreaterThan45()
    {
        employeeRepository.deleteEmployeeGreaterThan45(45);
    }
}
