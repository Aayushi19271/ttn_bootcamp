package com.SpringData.SpringDataJPA2_Assignment2.Question6to9.controller;

import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.entity.Check;
import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.entity.CreditCard;
import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.entity.Payment;
import com.SpringData.SpringDataJPA2_Assignment2.Question6to9.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    PaymentService paymentService;

    @PostMapping("/credit-card")
    public Payment createCreditCardPayment(@RequestBody CreditCard creditCard)
    {
        return paymentService.createPayment(creditCard);
    }

    @PostMapping("/check")
    public Payment createCheckPayment(@RequestBody Check check)
    {
        return paymentService.createCheckPayment(check);
    }

}
