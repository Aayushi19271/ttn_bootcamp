package com.SpringData.SpringDataJPA2_Assignment2.Question1to5.repository;

import com.SpringData.SpringDataJPA2_Assignment2.Question1to5.entity.Employee;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee,Integer> {

    //Find All Employees
    @Query("from Employee")
    List<Employee> findAllEmployee();

    //Display the first name, last name of all employees having salary greater than average salary ordered in ascending by their age and in descending by their salary.
    @Query("select firstName, lastName from Employee " +
            "where salary > (select AVG(salary) from Employee) " +
            "Order By age ASC,salary DESC ")
    List<Object[]> findAllEmployeePartialData();


    @Query("from Employee WHERE salary < (select AVG(salary) from Employee)")
    List<Employee> selectAllEmployeeSalary();


    //Update salary of all employees by a salary passed as a parameter whose existing salary is less than the average salary.
    @Modifying
    @Transactional
    @Query("update Employee SET salary=salary+:increment WHERE salary<:average")
    void updateAllEmployeeSalary(@Param("increment") Double increment,@Param("average") Double average);

    //Delete all employees with minimum salary.
    @Modifying
    @Transactional
    @Query("delete from Employee where salary<:minsalary")
    void deleteAllEmployeesMinSalary(@Param("minsalary") Double minSalary);

    @Query(value = "select * from employeetable where emplastname=:lastname", nativeQuery = true)
    List<Employee> findEmployeeLastNameNQ(@Param("lastname") String lastname);

    //Delete all employees with age greater than 45(Should be passed as a parameter)
    @Modifying
    @Transactional
    @Query(value = "delete from employeetable where empage>:age", nativeQuery = true)
    void  deleteEmployeeGreaterThan45(@Param("age") Integer age);

}
