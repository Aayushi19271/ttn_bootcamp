package com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.repository;

import com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.entity.EmployeeMapping;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepositoryMapping extends CrudRepository<EmployeeMapping,Integer> {
}
