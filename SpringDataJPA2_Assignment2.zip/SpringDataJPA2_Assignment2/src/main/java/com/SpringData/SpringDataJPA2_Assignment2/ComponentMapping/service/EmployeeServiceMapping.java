package com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.service;

import com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.entity.EmployeeMapping;
import com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.entity.Salary;
import com.SpringData.SpringDataJPA2_Assignment2.ComponentMapping.repository.EmployeeRepositoryMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceMapping {
    @Autowired
    EmployeeRepositoryMapping employeeRepositoryMapping;

    //CREATE A EMPLOYEE
    public void employeeCreate()
    {
        EmployeeMapping employeeMapping = new EmployeeMapping();
        employeeMapping.setFirstname("Aayushi");
        employeeMapping.setLastname("Thani");
        Salary salary = new Salary();
        salary.setBasicsalary(50000);
        salary.setBonussalary(6000);
        salary.setSpecialallowancesalary(3000);
        salary.setTaxamount(5000);
        employeeMapping.setSalary(salary);
        employeeRepositoryMapping.save(employeeMapping);
    }

    //FETCH THE LIST OF ALL EMPLOYEES
    public List<EmployeeMapping> findAllEmployee()
    {
        List<EmployeeMapping> employees = (List<EmployeeMapping>) employeeRepositoryMapping.findAll();
        return employees;
    }
}
