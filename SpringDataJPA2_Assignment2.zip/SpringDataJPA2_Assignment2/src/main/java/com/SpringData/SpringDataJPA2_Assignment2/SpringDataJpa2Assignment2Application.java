package com.SpringData.SpringDataJPA2_Assignment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpa2Assignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpa2Assignment2Application.class, args);
	}

}
