package com.Assignment3.SpringDataJPA3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpa3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
