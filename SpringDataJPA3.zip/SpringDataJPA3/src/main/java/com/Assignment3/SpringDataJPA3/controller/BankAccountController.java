package com.Assignment3.SpringDataJPA3.controller;


import com.Assignment3.SpringDataJPA3.entity.BankAccount;
import com.Assignment3.SpringDataJPA3.service.BankAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/bank")
public class BankAccountController {

    @Autowired
    BankAccountService bankAccountService;

    @GetMapping("/tranfer/{amount}")
    public List<BankAccount> bankTranfer(@PathVariable Integer amount)
    {
        List<BankAccount> bankAccountList = bankAccountService.bankTransfer(amount);
        return bankAccountList;
    }
}
