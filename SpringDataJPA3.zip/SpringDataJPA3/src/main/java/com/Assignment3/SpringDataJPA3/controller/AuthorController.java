package com.Assignment3.SpringDataJPA3.controller;

import com.Assignment3.SpringDataJPA3.entity.Author;
import com.Assignment3.SpringDataJPA3.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/authors")
public class AuthorController {

    @Autowired
    AuthorService authorService;

    @GetMapping("/create")
    public String createAuthor()
    {
        authorService.createAuthor();
        return "Author Added";
    }

    @GetMapping("/create-book")
    public String createAuthorBook()
    {
        authorService.createAuthorBook();
        return "Records Added to Author & Books";
    }

    @GetMapping("/create-book-m2o")
    private String createAuthorBookManyToOne()
    {
        authorService.createAuthorBookManyToOne();
        return "Records Added to Author & Books";
    }

    @GetMapping("/create-book-m2m")
    public String createAuthorBookManyToMany()
    {
        authorService.createAuthorBookManyToMany();
        return "Records Added to Author & Books";
    }

    @GetMapping("/caching")
    public void testCaching()
    {
       authorService.testCaching();
    }
}
