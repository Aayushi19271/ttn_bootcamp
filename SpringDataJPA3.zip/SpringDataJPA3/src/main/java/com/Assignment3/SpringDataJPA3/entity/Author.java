package com.Assignment3.SpringDataJPA3.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String name;
    @Embedded
    private Address address;
//    @OneToMany(mappedBy = "author",cascade = CascadeType.ALL)  //all changes you do on author , do them in subject table as well.
//    private List<Subject> subjects;

//    @OneToMany(mappedBy = "author",cascade = CascadeType.ALL)  //all changes you do on author , do them in subject table as well.
//    private List<Book> books;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "author_books",
            joinColumns = @JoinColumn(name = "author_id" ,referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "book_id",referencedColumnName = "id"))
    private List<Book> books;

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

//    public List<Subject> getSubjects() {
//        return subjects;
//    }
//
//    public void setSubjects(List<Subject> subjects) {
//        this.subjects = subjects;
//    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

//    public void addSubject(Subject subject)
//    {
//        if(subject != null)
//        {
//            if(subjects == null)
//                subjects = new ArrayList<>();
//        }
//        subject.setAuthor(this);
//        subjects.add(subject);
//    }
}
