package com.Assignment3.SpringDataJPA3.service;

import com.Assignment3.SpringDataJPA3.entity.Address;
import com.Assignment3.SpringDataJPA3.entity.Author;
import com.Assignment3.SpringDataJPA3.entity.Book;
import com.Assignment3.SpringDataJPA3.entity.Subject;
import com.Assignment3.SpringDataJPA3.repository.AuthorRepository;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AuthorService {

    @Autowired
    AuthorRepository authorRepository;

    @Autowired
    EntityManager entityManager;

    public void createAuthor()
    {
        Address address = new Address();
        address.setStreetnumber("AL76");
        address.setLocation("Pitampura");
        address.setState("Delhi");

        Subject subject1 = new Subject();
        subject1.setSubjectname("Java");
        Subject subject2 = new Subject();
        subject2.setSubjectname("Python");
        Subject subject3 = new Subject();
        subject3.setSubjectname("Groovy");


        Author author = new Author();
        author.setName("Aayushi");
        author.setAddress(address);

//        author.addSubject(subject1);
//        author.addSubject(subject2);
//        author.addSubject(subject3);

        authorRepository.save(author);
    }

    public void createAuthorBook()
    {
        Address address = new Address();
        address.setStreetnumber("AL76");
        address.setLocation("Pitampura");
        address.setState("Delhi");

        Subject subject1 = new Subject();
        subject1.setSubjectname("Java");
        Subject subject2 = new Subject();
        subject2.setSubjectname("Python");
        Subject subject3 = new Subject();
        subject3.setSubjectname("Groovy");


        Book book = new Book();
        book.setBookname("Java Advanced Guide");

        Author author = new Author();
        author.setName("Aayushi");
        author.setAddress(address);

//        author.addSubject(subject1);
//        author.addSubject(subject2);
//        author.addSubject(subject3);
//        author.setBook(book);

//        book.setAuthor(author);
        authorRepository.save(author);
    }

    public void createAuthorBookManyToOne()
    {
        Address address = new Address();
        address.setStreetnumber("AL76");
        address.setLocation("Pitampura");
        address.setState("Delhi");

        Subject subject1 = new Subject();
        subject1.setSubjectname("Java");
        Subject subject2 = new Subject();
        subject2.setSubjectname("Python");
        Subject subject3 = new Subject();
        subject3.setSubjectname("Groovy");


        List<Book> books = new ArrayList<Book>();
        Book book1 = new Book();
        book1.setBookname("Book1");
        Book book2 = new Book();
        book2.setBookname("Book2");
        Book book3 = new Book();
        book3.setBookname("Book3");
        books.add(book1);books.add(book2);books.add(book3);

        Author author = new Author();
        author.setName("Aayushi");
        author.setAddress(address);
        author.setBooks(books);

//        author.addSubject(subject1);
//        author.addSubject(subject2);
//        author.addSubject(subject3);
//
//        book1.setAuthor(author);
//        book2.setAuthor(author);
//        book3.setAuthor(author);
        authorRepository.save(author);
    }

    public void createAuthorBookManyToMany()
    {
        Address address = new Address();
        address.setStreetnumber("AL76");
        address.setLocation("Pitampura");
        address.setState("Delhi");

        List<Book> books = new ArrayList<Book>();
        Book book1 = new Book();
        book1.setBookname("Book1");
        Book book2 = new Book();
        book2.setBookname("Book2");
        Book book3 = new Book();
        book3.setBookname("Book3");
        books.add(book1);books.add(book2);books.add(book3);

        Author author = new Author();
        author.setName("Aayushi");
        author.setAddress(address);
        author.setBooks(books);

        authorRepository.save(author);

    }

    public Optional<Author> testCaching()
    {
        Session session = entityManager.unwrap(Session.class);
        Optional<Author> author = authorRepository.findById(1);

        authorRepository.findById(1);
        session.evict(author.get());
        authorRepository.findById(1);
        return author;
    }
}
