package com.Assignment3.SpringDataJPA3.service;

import com.Assignment3.SpringDataJPA3.entity.BankAccount;
import com.Assignment3.SpringDataJPA3.repository.BankAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class BankAccountService {

    @Autowired
    BankAccountRepository bankAccountRepository;

    @Transactional
    public List<BankAccount> bankTransfer(Integer amount)
    {
        BankAccount bankAccount1 = ((bankAccountRepository.findById(1)).get());
        bankAccount1.setBalance(bankAccount1.getBalance()-amount);
        bankAccountRepository.save(bankAccount1);

        if(true)
        {
            throw new RuntimeException();
        }

        BankAccount bankAccount2 = ((bankAccountRepository.findById(2)).get());
        bankAccount2.setBalance(bankAccount2.getBalance()+amount);
        bankAccountRepository.save(bankAccount2);
        List<BankAccount> bankAccountList = (List<BankAccount>) bankAccountRepository.findAll();

        return bankAccountList;
    }
}
